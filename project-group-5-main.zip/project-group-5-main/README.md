# COMP4651-24Fall-Project

To make sure the repo can be updated properly,
- [Download full data here](https://hkustconnect-my.sharepoint.com/:f:/g/personal/hwkwong_connect_ust_hk/Ek4N3hjOj6NOsohqaiFcoZsBZGOpwTmS3ny58cs43l6O9Q?e=KfsLvN)
- Alternatively, a [compact version of transformed data](https://hkustconnect-my.sharepoint.com/:x:/g/personal/hwkwong_connect_ust_hk/Ec0MeHXlWJdHvzt8aepxed8BYpSkjvhpKv1zLqSSTrBlHw?e=1oyETQ)
